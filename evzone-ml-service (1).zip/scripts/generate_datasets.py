from __future__ import annotations

from pathlib import Path

from evzone_ml.data.synthetic_data import save_datasets


def main() -> None:
    out_dir = Path("src/evzone_ml/data/datasets")
    paths = save_datasets(out_dir)
    print("Generated datasets:")
    for name, p in paths.items():
        print(f" - {name}: {p}")


if __name__ == "__main__":
    main()

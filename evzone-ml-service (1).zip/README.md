# EVzone Independent ML Service (Starter Package)

This repository is a **starter code package** for an **independent, cloud-deployable ML Service**
that supports:

- **Failure Prediction** (`/api/v1/predictions/failure`)
- **Anomaly Detection** (`/api/v1/anomaly/detect`)
- **Maintenance Scheduling Optimization** (`/api/v1/maintenance/recommend`)
- **Kafka ingestion** (`charger.metrics`) + optional publishing (`charger.anomalies`)

It also includes the **synthetic datasets** you requested:
- `synthetic_charger_metrics.csv` (1000+ rows)
- `synthetic_charger_metrics.json` (JSON array)
- `synthetic_battery_pack_metrics.json` (swap-ready, future)
- `training_dataset.csv` (labeled for failure prediction)
- `test_dataset.json` (live-style API payloads)

> NOTE: The models shipped are **baseline** models trained on synthetic data to make the service runnable
> immediately. Replace with real data and retrain for production.

---

## 1) Quickstart (Local)

### Requirements
- Python 3.10+ recommended

### Setup
```bash
cd evzone-ml-service
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pip install -e .
```

### Run the API
```bash
uvicorn evzone_ml.api.main:app --reload --port 8000
```

### Health check
```bash
curl http://localhost:8000/health
```

---

## 2) Example Requests

### Failure prediction
```bash
curl -X POST http://localhost:8000/api/v1/predictions/failure \
  -H "Content-Type: application/json" \
  -H "X-Tenant-ID: demo-tenant" \
  -d '{
    "charger_id":"charger_123",
    "metrics":{
      "charger_id":"charger_123",
      "connector_status":"CHARGING",
      "energy_delivered":150.75,
      "power":7.2,
      "temperature":38.5,
      "error_codes":["E_OVER_TEMP"],
      "uptime_hours":720.5,
      "total_sessions":150,
      "last_maintenance":"2025-12-01T10:00:00Z",
      "metadata":{"cost_per_kwh":3000}
    }
  }'
```

### Anomaly detection
```bash
curl -X POST http://localhost:8000/api/v1/anomaly/detect \
  -H "Content-Type: application/json" \
  -H "X-Tenant-ID: demo-tenant" \
  -d '{
    "charger_id":"charger_123",
    "timestamp":"2026-01-04T12:00:00Z",
    "connector_status":"CHARGING",
    "energy_delivered":150.75,
    "power":7.2,
    "temperature":55.0,
    "error_codes":["E_OVER_TEMP"]
  }'
```

### Maintenance recommendation
```bash
curl -X POST http://localhost:8000/api/v1/maintenance/recommend \
  -H "Content-Type: application/json" \
  -H "X-Tenant-ID: demo-tenant" \
  -d '{
    "charger_id":"charger_123",
    "metrics":{
      "charger_id":"charger_123",
      "connector_status":"AVAILABLE",
      "energy_delivered":100.5,
      "power":7.2,
      "temperature":25.0,
      "error_codes":[],
      "uptime_hours":2000,
      "total_sessions":850,
      "last_maintenance":"2025-10-01T10:00:00Z",
      "metadata":{"cost_per_kwh":3000}
    }
  }'
```

---

## 3) Kafka (Optional, Local via Docker Compose)

This package includes a `docker-compose.yml` that starts:
- Zookeeper
- Kafka broker
- The ML service API container

```bash
docker compose up --build
```

Then publish test messages to `charger.metrics` using any Kafka tool/client.  
You can also enable the consumer inside the ML service by setting:
- `ENABLE_KAFKA_CONSUMER=true`

---

## 4) Generate Datasets / Retrain Models

### Generate datasets
```bash
python scripts/generate_datasets.py
```

### Train baseline models
```bash
python scripts/train_failure_model.py
python scripts/train_anomaly_model.py
```

---

## 5) Project Layout
```
src/evzone_ml/
  api/               FastAPI endpoints + schemas
  ml/                Feature engineering + ML models + optimizer
  streaming/          Kafka consumer/producer
  data/               Synthetic data generator + datasets
models/               Saved baseline model artifacts (*.joblib)
scripts/              Dataset generation & training scripts
tests/                Minimal tests
```

---

## 6) Production Notes (Very Important)
- Replace synthetic data with real telemetry ASAP.
- Add authentication (JWT/OAuth) + per-tenant access controls.
- Add model monitoring: drift + performance + alert fatigue controls.
- Add data quality checks and schema registry for Kafka payloads.


from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field, ConfigDict


class APIBaseModel(BaseModel):
    # Allow fields like "model_version" without warnings.
    model_config = ConfigDict(protected_namespaces=())


# -------------------------
# Shared / Input schemas
# -------------------------

ConnectorStatus = Literal[
    "AVAILABLE",
    "CHARGING",
    "OCCUPIED",
    "UNAVAILABLE",
    "OFFLINE",
    "FAULTY",
    "FULLY_CHARGED",
]


class ChargerMetrics(APIBaseModel):
    charger_id: str = Field(..., examples=["charger_123"])
    connector_status: ConnectorStatus = Field(..., examples=["AVAILABLE"])
    energy_delivered: float = Field(0.0, ge=0, examples=[100.5])
    power: float = Field(0.0, ge=0, examples=[7.2])
    temperature: float = Field(0.0, examples=[25.0])
    error_codes: List[str] = Field(default_factory=list, examples=[[]])
    uptime_hours: float = Field(0.0, ge=0, examples=[720.5])
    total_sessions: int = Field(0, ge=0, examples=[150])
    last_maintenance: Optional[datetime] = Field(None, examples=["2025-12-01T10:00:00Z"])
    metadata: Dict[str, Any] = Field(default_factory=dict)


class FailurePredictionRequest(APIBaseModel):
    charger_id: str
    metrics: ChargerMetrics


class AnomalyDetectionRequest(APIBaseModel):
    charger_id: str
    timestamp: datetime
    connector_status: ConnectorStatus
    energy_delivered: float = 0.0
    power: float = 0.0
    temperature: float = 0.0
    error_codes: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class MaintenanceRecommendationRequest(APIBaseModel):
    charger_id: str
    metrics: ChargerMetrics


# -------------------------
# Output schemas
# -------------------------

Urgency = Literal["LOW", "MEDIUM", "HIGH", "CRITICAL"]
ActionWindow = Literal["IMMEDIATE", "WITHIN_7_DAYS", "WITHIN_30_DAYS"]


class PredictedFailureWindow(APIBaseModel):
    start: datetime
    end: datetime


class FailurePredictionResponse(APIBaseModel):
    charger_id: str
    tenant_id: Optional[str] = None

    failure_probability: float = Field(..., ge=0.0, le=1.0)
    predicted_failure_window: PredictedFailureWindow
    confidence_score: float = Field(..., ge=0.0, le=1.0)

    recommended_action_window: ActionWindow
    recommended_actions: List[str] = Field(default_factory=list)

    top_contributing_factors: List[str] = Field(default_factory=list)

    model_version: str = "baseline-1"


class AnomalyDetectionResponse(APIBaseModel):
    charger_id: str
    tenant_id: Optional[str] = None

    is_anomaly: bool
    anomaly_score: float = Field(..., ge=0.0, le=100.0)
    anomaly_type: str
    deviation: Dict[str, float] = Field(default_factory=dict)

    model_version: str = "baseline-1"


class CostBenefitAnalysis(APIBaseModel):
    preventive_maintenance_cost: float
    expected_failure_cost: float
    net_savings: float


class MaintenanceRecommendationResponse(APIBaseModel):
    charger_id: str
    tenant_id: Optional[str] = None

    recommended_maintenance_datetime: datetime
    urgency_level: Urgency
    estimated_downtime_hours: float

    cost_benefit: CostBenefitAnalysis
    rationale: List[str] = Field(default_factory=list)

    model_version: str = "baseline-1"

from __future__ import annotations

import logging
from fastapi import FastAPI

from ..core.logging import setup_logging
from ..core.config import settings
from .routes import router as api_router

logger = logging.getLogger(__name__)

setup_logging()

app = FastAPI(title=settings.APP_NAME, version="0.1.0")


@app.get("/health")
def health():
    return {"status": "ok", "service": settings.APP_NAME}


app.include_router(api_router)


# Optional: Start Kafka consumer on startup (disabled by default)
@app.on_event("startup")
def _startup():
    logger.info("Starting %s", settings.APP_NAME)
    if settings.ENABLE_KAFKA_CONSUMER:
        from ..streaming.kafka_consumer import start_consumer_thread

        start_consumer_thread()
        logger.info("Kafka consumer enabled")
    else:
        logger.info("Kafka consumer disabled")

from __future__ import annotations

import logging
from fastapi import APIRouter, Header, HTTPException

from ..core.config import settings
from .schemas import (
    AnomalyDetectionRequest,
    AnomalyDetectionResponse,
    FailurePredictionRequest,
    FailurePredictionResponse,
    MaintenanceRecommendationRequest,
    MaintenanceRecommendationResponse,
)
from ..ml.failure_model import FailurePredictor
from ..ml.anomaly_model import AnomalyDetector
from ..ml.maintenance_optimizer import MaintenanceOptimizer

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1")

# Lazy singletons (keeps demo simple; in production use dependency injection)
_failure_predictor = FailurePredictor()
_anomaly_detector = AnomalyDetector()
_maintenance_optimizer = MaintenanceOptimizer()


def _get_tenant_id(x_tenant_id: str | None) -> str | None:
    return x_tenant_id


@router.post("/predictions/failure", response_model=FailurePredictionResponse)
def predict_failure(
    payload: FailurePredictionRequest,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-ID"),
):
    try:
        tenant_id = _get_tenant_id(x_tenant_id)
        result = _failure_predictor.predict(payload.metrics, tenant_id=tenant_id)
        return result
    except Exception as e:
        logger.exception("Failure prediction error")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/anomaly/detect", response_model=AnomalyDetectionResponse)
def detect_anomaly(
    payload: AnomalyDetectionRequest,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-ID"),
):
    try:
        tenant_id = _get_tenant_id(x_tenant_id)
        result = _anomaly_detector.detect(payload, tenant_id=tenant_id)
        return result
    except Exception as e:
        logger.exception("Anomaly detection error")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/maintenance/recommend", response_model=MaintenanceRecommendationResponse)
def recommend_maintenance(
    payload: MaintenanceRecommendationRequest,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-ID"),
):
    try:
        tenant_id = _get_tenant_id(x_tenant_id)

        # Use the failure predictor as an input to the optimizer
        failure_pred = _failure_predictor.predict(payload.metrics, tenant_id=tenant_id)

        result = _maintenance_optimizer.recommend(
            metrics=payload.metrics,
            failure_prediction=failure_pred,
            tenant_id=tenant_id,
        )
        return result
    except Exception as e:
        logger.exception("Maintenance recommendation error")
        raise HTTPException(status_code=500, detail=str(e))

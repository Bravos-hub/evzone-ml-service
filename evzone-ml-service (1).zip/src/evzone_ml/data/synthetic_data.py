from __future__ import annotations

import json
import math
import random
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd


CONNECTOR_STATUSES = [
    "AVAILABLE",
    "CHARGING",
    "OCCUPIED",
    "UNAVAILABLE",
    "OFFLINE",
    "FAULTY",
    "FULLY_CHARGED",
]

ERROR_CODES_POOL = [
    "E_OVER_TEMP",
    "E_COMM_TIMEOUT",
    "E_GFCI_TRIP",
    "E_CONTACTOR",
    "E_METER",
    "E_RELAY",
]


def _sigmoid(x: float) -> float:
    return 1.0 / (1.0 + math.exp(-x))


def generate_synthetic_charger_metrics(
    n_rows: int = 2500,
    n_chargers: int = 25,
    tenants: List[str] | None = None,
    start_time: datetime | None = None,
    freq_minutes: int = 10,
    seed: int = 42,
) -> pd.DataFrame:
    """Generate a synthetic time-series dataset of charger telemetry."""
    random.seed(seed)
    np.random.seed(seed)

    tenants = tenants or ["tenant_a", "tenant_b", "tenant_c"]
    start_time = start_time or (datetime.now(timezone.utc) - timedelta(days=14))

    rows = []
    for i in range(n_rows):
        tenant_id = random.choice(tenants)
        charger_id = f"charger_{random.randint(1, n_chargers):03d}"

        ts = start_time + timedelta(minutes=i * freq_minutes / max(1, n_chargers // 5))

        # baseline values
        power = max(0.0, np.random.normal(7.0, 1.0))
        energy_delivered = max(0.0, np.random.normal(20.0, 15.0))

        temperature = float(np.random.normal(30.0, 5.0))
        uptime_hours = float(max(0.0, np.random.normal(1500, 600)))
        total_sessions = int(max(0, np.random.normal(350, 200)))

        days_since_maintenance = max(0.0, np.random.exponential(scale=60.0))
        last_maintenance = (ts - timedelta(days=float(days_since_maintenance))).isoformat().replace("+00:00", "Z")

        # status distribution influenced by temperature/errors
        base_status = random.choices(
            population=["AVAILABLE", "CHARGING", "OCCUPIED", "FULLY_CHARGED"],
            weights=[0.35, 0.35, 0.20, 0.10],
        )[0]

        # error generation
        error_codes = []
        if temperature > 45 and random.random() < 0.35:
            error_codes.append("E_OVER_TEMP")
        if uptime_hours > 2500 and random.random() < 0.15:
            error_codes.append(random.choice(["E_CONTACTOR", "E_RELAY"]))
        if random.random() < 0.05:
            error_codes.append(random.choice(ERROR_CODES_POOL))

        # push some into faulty/offline when risk factors are high
        risk = 0.02 * (temperature - 30) + 0.4 * len(error_codes) + 0.0002 * uptime_hours + 0.0007 * total_sessions + 0.01 * max(days_since_maintenance - 60, 0)
        p_fault = _sigmoid(risk - 2.0)
        if random.random() < p_fault:
            base_status = random.choice(["UNAVAILABLE", "OFFLINE", "FAULTY"])

        # if charging, bump power & energy
        if base_status == "CHARGING":
            power = max(1.0, np.random.normal(7.2, 1.2))
            energy_delivered = max(0.5, np.random.normal(30.0, 12.0))
            temperature += abs(np.random.normal(3.0, 2.0))

        # fully charged => power low
        if base_status == "FULLY_CHARGED":
            power = max(0.0, np.random.normal(0.2, 0.2))

        # faulty/offline often has low power
        if base_status in {"FAULTY", "OFFLINE", "UNAVAILABLE"}:
            power = max(0.0, np.random.normal(0.1, 0.2))

        rows.append(
            {
                "tenant_id": tenant_id,
                "charger_id": charger_id,
                "timestamp": ts.isoformat().replace("+00:00", "Z"),
                "connector_status": base_status,
                "energy_delivered": float(round(energy_delivered, 3)),
                "power": float(round(power, 3)),
                "temperature": float(round(temperature, 2)),
                "error_codes": error_codes,
                "uptime_hours": float(round(uptime_hours, 2)),
                "total_sessions": int(total_sessions),
                "last_maintenance": last_maintenance,
                "metadata": {"cost_per_kwh": 3000},
            }
        )

    return pd.DataFrame(rows)


def generate_training_dataset(metrics_df: pd.DataFrame, seed: int = 42) -> pd.DataFrame:
    """Create a supervised training table with a failure label.

    We synthesize labels based on risk factors to bootstrap the pipeline.
    Replace this with true labels derived from real failure/maintenance events ASAP.
    """
    random.seed(seed)
    np.random.seed(seed)

    def risk_row(r):
        temp = float(r["temperature"])
        err = len(r["error_codes"]) if isinstance(r["error_codes"], list) else 0
        uptime = float(r["uptime_hours"])
        sessions = float(r["total_sessions"])
        # maintenance recency proxy from timestamp-last_maintenance
        try:
            ts = datetime.fromisoformat(str(r["timestamp"]).replace("Z", "+00:00"))
            lm = datetime.fromisoformat(str(r["last_maintenance"]).replace("Z", "+00:00"))
            days = max((ts - lm).total_seconds() / 86400.0, 0.0)
        except Exception:
            days = 9999.0
        status = str(r["connector_status"])
        status_penalty = 2.0 if status in {"FAULTY", "OFFLINE", "UNAVAILABLE"} else 0.0

        score = 0.03 * (temp - 30) + 0.55 * err + 0.00025 * uptime + 0.0009 * sessions + 0.006 * max(days - 90, 0) + status_penalty
        return _sigmoid(score - 2.2)

    probs = metrics_df.apply(risk_row, axis=1)
    # Define labels: failure within 30d
    y = (probs > 0.65).astype(int)

    out = metrics_df.copy()
    out["failure_probability_synth"] = probs.round(5)
    out["failure_within_30d_label"] = y

    # Add a coarser multi-window label to support recommended action windows
    out["failure_within_7d_label"] = (probs > 0.80).astype(int)
    out["failure_within_1d_label"] = (probs > 0.90).astype(int)
    return out


def generate_synthetic_battery_pack_metrics(
    n_packs: int = 100,
    n_rows: int = 500,
    station_ids: List[str] | None = None,
    seed: int = 123,
) -> List[Dict]:
    random.seed(seed)
    np.random.seed(seed)

    station_ids = station_ids or ["STN-UG-WDG-01", "STN-KE-NBO-02", "STN-TZ-DSM-01"]

    start = datetime.now(timezone.utc) - timedelta(days=30)

    rows = []
    for i in range(n_rows):
        pack_id = f"PCK-{random.randint(1, n_packs):03d}"
        station_id = random.choice(station_ids)
        ts = start + timedelta(minutes=i * 30)

        soh = float(np.clip(np.random.normal(92, 5), 50, 100))
        soc = float(np.clip(np.random.normal(65, 20), 0, 100))
        temp = float(np.random.normal(32, 6))
        voltage = float(np.clip(np.random.normal(52, 2), 44, 60))
        cycle_count = int(max(0, np.random.normal(400, 250)))

        errors = []
        if temp > 55 and random.random() < 0.4:
            errors.append("PCK_OVER_TEMP")
        if soh < 70 and random.random() < 0.2:
            errors.append("PCK_LOW_SOH")

        rows.append(
            {
                "pack_id": pack_id,
                "station_id": station_id,
                "timestamp": ts.isoformat().replace("+00:00", "Z"),
                "soc": round(soc, 2),
                "soh": round(soh, 2),
                "temperature": round(temp, 2),
                "voltage": round(voltage, 2),
                "cycle_count": cycle_count,
                "error_codes": errors,
            }
        )
    return rows


def save_datasets(base_dir: Path) -> Dict[str, Path]:
    base_dir.mkdir(parents=True, exist_ok=True)

    # 1) charger metrics
    df = generate_synthetic_charger_metrics(n_rows=2500)
    csv_path = base_dir / "synthetic_charger_metrics.csv"
    json_path = base_dir / "synthetic_charger_metrics.json"
    df.to_csv(csv_path, index=False)
    df.to_json(json_path, orient="records", indent=2)

    # 2) training dataset
    train_df = generate_training_dataset(df)
    train_path = base_dir / "training_dataset.csv"
    train_df.to_csv(train_path, index=False)

    # 3) test dataset (live-style payloads)
    test_payloads = []
    sample = df.sample(n=25, random_state=7)
    for _, r in sample.iterrows():
        test_payloads.append(
            {
                "charger_id": r["charger_id"],
                "metrics": {
                    "charger_id": r["charger_id"],
                    "connector_status": r["connector_status"],
                    "energy_delivered": float(r["energy_delivered"]),
                    "power": float(r["power"]),
                    "temperature": float(r["temperature"]),
                    "error_codes": r["error_codes"] if isinstance(r["error_codes"], list) else [],
                    "uptime_hours": float(r["uptime_hours"]),
                    "total_sessions": int(r["total_sessions"]),
                    "last_maintenance": r["last_maintenance"],
                    "metadata": r["metadata"] if isinstance(r["metadata"], dict) else {"cost_per_kwh": 3000},
                },
            }
        )
    test_path = base_dir / "test_dataset.json"
    test_path.write_text(json.dumps(test_payloads, indent=2), encoding="utf-8")

    # 4) swap-ready pack metrics
    pack_rows = generate_synthetic_battery_pack_metrics(n_rows=600)
    pack_path = base_dir / "synthetic_battery_pack_metrics.json"
    pack_path.write_text(json.dumps(pack_rows, indent=2), encoding="utf-8")

    return {
        "synthetic_charger_metrics.csv": csv_path,
        "synthetic_charger_metrics.json": json_path,
        "training_dataset.csv": train_path,
        "test_dataset.json": test_path,
        "synthetic_battery_pack_metrics.json": pack_path,
    }

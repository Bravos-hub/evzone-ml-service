from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Optional

import joblib
import numpy as np

from ..api.schemas import AnomalyDetectionRequest, AnomalyDetectionResponse
from ..core.config import settings
from .feature_engineering import STATUS_TO_INT

logger = logging.getLogger(__name__)


class _RuleBasedAnomalyModel:
    def score_samples(self, X: np.ndarray) -> np.ndarray:
        # Higher score = more normal (mimic sklearn IsolationForest behavior)
        scores = []
        for row in X:
            status_int, energy, power, temp, err_cnt = row
            # crude normality score
            s = 0.0
            if temp > 60:
                s -= 2.0
            elif temp > 50:
                s -= 1.0
            if err_cnt > 0:
                s -= 0.5 * min(err_cnt, 5)
            if status_int >= 4:
                s -= 2.0
            if power < 0:
                s -= 1.0
            # convert to a "normality" like score
            scores.append(s)
        return np.array(scores, dtype=float)


@dataclass
class _LoadedAnomalyModel:
    model: object
    raw_min: float = 0.0
    raw_max: float = 1.0
    mean: Optional[np.ndarray] = None
    std: Optional[np.ndarray] = None


class AnomalyDetector:
    def __init__(self, model_path: Optional[str] = None):
        model_dir = Path(settings.MODEL_DIR)
        self.model_path = Path(model_path) if model_path else (model_dir / "anomaly_model.joblib")
        self.loaded = self._load_model()

    def _load_model(self) -> _LoadedAnomalyModel:
        if self.model_path.exists():
            try:
                obj = joblib.load(self.model_path)
                if isinstance(obj, dict) and "model" in obj:
                    return _LoadedAnomalyModel(
                        model=obj["model"],
                        raw_min=float(obj.get("raw_min", 0.0)),
                        raw_max=float(obj.get("raw_max", 1.0)),
                        mean=np.array(obj.get("mean")) if obj.get("mean") is not None else None,
                        std=np.array(obj.get("std")) if obj.get("std") is not None else None,
                    )
                return _LoadedAnomalyModel(model=obj)
            except Exception:
                logger.exception("Failed to load anomaly model; using rule-based fallback")
        return _LoadedAnomalyModel(model=_RuleBasedAnomalyModel(), raw_min=0.0, raw_max=3.0)

    @staticmethod
    def _features(payload: AnomalyDetectionRequest) -> np.ndarray:
        status_int = float(STATUS_TO_INT.get(payload.connector_status, 0))
        err_cnt = float(len(payload.error_codes or []))
        return np.array([[status_int, payload.energy_delivered, payload.power, payload.temperature, err_cnt]], dtype=float)

    def _raw_anomaly(self, X: np.ndarray) -> float:
        # IsolationForest: higher score_samples => more normal
        model = self.loaded.model
        if hasattr(model, "score_samples"):
            normality = float(model.score_samples(X)[0])
            raw = -normality
            return raw
        # fallback
        normality = float(model.score_samples(X)[0])
        return -normality

    def _normalize_score(self, raw: float) -> float:
        # Map raw anomaly to 0..100
        mn = self.loaded.raw_min
        mx = self.loaded.raw_max
        if mx <= mn:
            return float(min(max(raw * 100.0, 0.0), 100.0))
        score = (raw - mn) / (mx - mn)
        return float(min(max(score * 100.0, 0.0), 100.0))

    def _deviation(self, X: np.ndarray) -> Dict[str, float]:
        # z-score deviations, if mean/std were stored at training time
        if self.loaded.mean is None or self.loaded.std is None:
            return {}
        std = np.where(self.loaded.std == 0, 1.0, self.loaded.std)
        z = (X[0] - self.loaded.mean) / std
        keys = ["status_int", "energy_delivered", "power", "temperature", "error_count"]
        return {k: float(v) for k, v in zip(keys, z)}

    @staticmethod
    def _classify(payload: AnomalyDetectionRequest, anomaly_score: float) -> str:
        if payload.connector_status in {"FAULTY", "OFFLINE", "UNAVAILABLE"}:
            return "STATUS_FAULT"
        if payload.temperature >= 60:
            return "OVER_TEMPERATURE_CRITICAL"
        if payload.temperature >= 50:
            return "OVER_TEMPERATURE"
        if payload.error_codes:
            return "ERROR_CODE_PRESENT"
        if payload.connector_status == "CHARGING" and payload.power <= 0.1:
            return "POWER_DROP_DURING_CHARGING"
        if anomaly_score >= 80:
            return "GENERIC_OUTLIER_HIGH"
        if anomaly_score >= 50:
            return "GENERIC_OUTLIER_MEDIUM"
        return "NORMAL"

    def detect(self, payload: AnomalyDetectionRequest, tenant_id: Optional[str] = None) -> AnomalyDetectionResponse:
        X = self._features(payload)
        raw = self._raw_anomaly(X)
        score = self._normalize_score(raw)
        deviation = self._deviation(X)

        # threshold (tune for production)
        is_anomaly = bool(score >= 60.0)
        anomaly_type = self._classify(payload, score)

        return AnomalyDetectionResponse(
            charger_id=payload.charger_id,
            tenant_id=tenant_id,
            is_anomaly=is_anomaly,
            anomaly_score=score,
            anomaly_type=anomaly_type,
            deviation=deviation,
        )

from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import List, Optional

from ..api.schemas import (
    ChargerMetrics,
    CostBenefitAnalysis,
    FailurePredictionResponse,
    MaintenanceRecommendationResponse,
)

logger = logging.getLogger(__name__)


class MaintenanceOptimizer:
    """Rule + light optimization based maintenance recommender.

    This is intentionally simple for a starter package. In production, replace with
    a true optimization model that uses usage forecasts, technician availability,
    site constraints (N-1 redundancy), etc.
    """

    def _urgency(self, pred: FailurePredictionResponse, metrics: ChargerMetrics) -> str:
        prob = pred.failure_probability
        if metrics.connector_status in {"FAULTY", "OFFLINE", "UNAVAILABLE"} or prob >= 0.85:
            return "CRITICAL"
        if prob >= 0.60:
            return "HIGH"
        if prob >= 0.40:
            return "MEDIUM"
        return "LOW"

    def _estimate_downtime_hours(self, metrics: ChargerMetrics, pred: FailurePredictionResponse) -> float:
        base = 2.0
        if metrics.error_codes:
            base += 1.0
        if metrics.temperature >= 50:
            base += 1.5
        elif metrics.temperature >= 40:
            base += 0.5
        if metrics.total_sessions >= 500:
            base += 0.5
        if metrics.connector_status in {"FAULTY", "OFFLINE", "UNAVAILABLE"}:
            base += 2.0
        return float(min(max(base, 1.0), 12.0))

    def _pick_maintenance_datetime(
        self,
        pred: FailurePredictionResponse,
        urgency: str,
    ) -> datetime:
        now = datetime.now(timezone.utc)

        # Default: schedule next day at 02:00 UTC (often low usage).
        candidate = (now + timedelta(days=1)).replace(hour=2, minute=0, second=0, microsecond=0)

        # If critical/high, ensure maintenance is before predicted failure window start
        latest = pred.predicted_failure_window.start

        if urgency in {"CRITICAL", "HIGH"}:
            # If candidate is too late, pull it earlier (tonight 02:00 UTC if still ahead)
            tonight_2am = now.replace(hour=2, minute=0, second=0, microsecond=0)
            if tonight_2am > now and tonight_2am < latest:
                candidate = tonight_2am
            else:
                # Choose earliest safe time within next few hours
                candidate = now + timedelta(hours=2)

        # If still after latest, force immediate scheduling
        if candidate >= latest:
            candidate = now + timedelta(hours=1)

        return candidate

    def _cost_benefit(
        self,
        metrics: ChargerMetrics,
        pred: FailurePredictionResponse,
        downtime_hours: float,
        urgency: str,
    ) -> CostBenefitAnalysis:
        # Very rough economics.
        # If cost_per_kwh not known, assume "1.0 unit" per kWh.
        cost_per_kwh = float(metrics.metadata.get("cost_per_kwh", 1.0))
        # Approx revenue per hour ~= power(kW) * cost/kWh * utilization
        # Utilization factor: higher during day. We approximate with 0.3 baseline.
        utilization = float(metrics.metadata.get("utilization_factor", 0.30))
        power_kw = max(float(metrics.power or 0.0), 1.0)

        revenue_per_hour = power_kw * cost_per_kwh * utilization

        preventive_labor_cost = float(metrics.metadata.get("preventive_labor_cost", 100.0))
        repair_cost = float(metrics.metadata.get("repair_cost", 250.0))

        preventive_maintenance_cost = downtime_hours * revenue_per_hour + preventive_labor_cost

        failure_downtime = 8.0 if urgency in {"LOW", "MEDIUM"} else 16.0
        expected_failure_cost = pred.failure_probability * (failure_downtime * revenue_per_hour + repair_cost)

        net_savings = expected_failure_cost - preventive_maintenance_cost

        return CostBenefitAnalysis(
            preventive_maintenance_cost=float(round(preventive_maintenance_cost, 4)),
            expected_failure_cost=float(round(expected_failure_cost, 4)),
            net_savings=float(round(net_savings, 4)),
        )

    def recommend(
        self,
        metrics: ChargerMetrics,
        failure_prediction: FailurePredictionResponse,
        tenant_id: Optional[str] = None,
    ) -> MaintenanceRecommendationResponse:
        urgency = self._urgency(failure_prediction, metrics)
        downtime = self._estimate_downtime_hours(metrics, failure_prediction)
        when = self._pick_maintenance_datetime(failure_prediction, urgency)
        cost_benefit = self._cost_benefit(metrics, failure_prediction, downtime, urgency)

        rationale: List[str] = []
        rationale.append(f"Failure probability={failure_prediction.failure_probability:.2f}")
        rationale.append(f"Predicted failure window starts={failure_prediction.predicted_failure_window.start.isoformat()}")
        if metrics.error_codes:
            rationale.append(f"Error codes present: {', '.join(metrics.error_codes[:3])}")
        if metrics.temperature >= 40:
            rationale.append(f"Elevated temperature: {metrics.temperature:.1f}°C")
        if metrics.last_maintenance:
            rationale.append(f"Last maintenance: {metrics.last_maintenance.isoformat()}")
        else:
            rationale.append("No maintenance record found")

        return MaintenanceRecommendationResponse(
            charger_id=metrics.charger_id,
            tenant_id=tenant_id,
            recommended_maintenance_datetime=when,
            urgency_level=urgency,  # type: ignore[arg-type]
            estimated_downtime_hours=downtime,
            cost_benefit=cost_benefit,
            rationale=rationale,
        )

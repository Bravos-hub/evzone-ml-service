from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import List, Optional

import joblib
import numpy as np

from ..api.schemas import ChargerMetrics, FailurePredictionResponse, PredictedFailureWindow
from ..core.config import settings
from .feature_engineering import extract_features, features_to_vector

logger = logging.getLogger(__name__)


class _RuleBasedFailureModel:
    """Fallback if no trained model is available."""

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        # X shape: (n, features)
        out = []
        for row in X:
            # crude scoring
            status_int, energy, power, temp, err_cnt, uptime, sessions, days_since = row
            score = 0.0
            score += 0.02 * (temp - 25.0)
            score += 0.3 * min(err_cnt, 5.0)
            score += 0.0002 * uptime
            score += 0.0005 * sessions
            score += 0.001 * max(days_since - 30.0, 0.0)
            # status penalty if offline/faulty/unavailable
            if status_int >= 4:
                score += 2.0
            prob = 1.0 / (1.0 + np.exp(-score))
            out.append([1 - prob, prob])
        return np.array(out, dtype=float)


class FailurePredictor:
    def __init__(self, model_path: Optional[str] = None):
        model_dir = Path(settings.MODEL_DIR)
        self.model_path = Path(model_path) if model_path else (model_dir / "failure_model.joblib")
        self.model = self._load_model()

    def _load_model(self):
        if self.model_path.exists():
            try:
                logger.info("Loading failure model from %s", self.model_path)
                return joblib.load(self.model_path)
            except Exception:
                logger.exception("Failed to load failure model; using rule-based fallback")
        return _RuleBasedFailureModel()

    @staticmethod
    def _confidence(prob: float) -> float:
        # High confidence when far from 0.5
        return float(min(max(abs(prob - 0.5) * 2.0, 0.0), 1.0))

    @staticmethod
    def _recommend_action_window(prob: float, metrics: ChargerMetrics) -> str:
        if metrics.connector_status in {"FAULTY", "OFFLINE", "UNAVAILABLE"}:
            return "IMMEDIATE"
        if prob >= 0.85:
            return "IMMEDIATE"
        if prob >= 0.60:
            return "WITHIN_7_DAYS"
        return "WITHIN_30_DAYS"

    @staticmethod
    def _recommend_actions(prob: float, metrics: ChargerMetrics) -> List[str]:
        actions: List[str] = []

        # Status based
        if metrics.connector_status in {"FAULTY", "OFFLINE", "UNAVAILABLE"}:
            actions.append("Run remote diagnostics and attempt controlled reboot.")
            actions.append("Inspect charger hardware and connector for physical damage.")

        # Temperature based
        if metrics.temperature >= 50:
            actions.append("Inspect cooling system / ventilation; check for fan failure or blocked airflow.")
        elif metrics.temperature >= 40:
            actions.append("Monitor temperature trend; clean filters and verify thermal sensors.")

        # Error codes
        if metrics.error_codes:
            actions.append("Review recent error codes and correlate with OEM troubleshooting guide.")
            actions.append("Check communication link (network/modem) and power electronics logs.")

        # Maintenance age
        if metrics.last_maintenance is None:
            actions.append("No maintenance history found; schedule baseline inspection and commissioning checks.")
        else:
            # simple heuristic
            days_since = (datetime.now(timezone.utc) - metrics.last_maintenance).days if metrics.last_maintenance.tzinfo else 9999
            if days_since > 180:
                actions.append("Schedule preventive maintenance (inspection, torque checks, firmware update).")
            elif days_since > 90:
                actions.append("Plan routine maintenance in next available low-usage window.")

        # Utilization
        if metrics.total_sessions >= 500:
            actions.append("High utilization: inspect connector wear and contactor cycles.")

        # Probability based
        if prob >= 0.85:
            actions.append("Escalate to technician: prioritize site visit within 24 hours.")
        elif prob >= 0.60:
            actions.append("Plan technician visit within 7 days.")
        else:
            actions.append("Continue monitoring; re-score daily and act if risk increases.")

        # Deduplicate while preserving order
        deduped = []
        seen = set()
        for a in actions:
            if a not in seen:
                seen.add(a)
                deduped.append(a)
        return deduped

    @staticmethod
    def _top_factors(metrics: ChargerMetrics) -> List[str]:
        factors = []
        if metrics.error_codes:
            factors.append(f"Recent error codes: {', '.join(metrics.error_codes[:3])}")
        if metrics.temperature >= 45:
            factors.append(f"High temperature: {metrics.temperature:.1f}°C")
        if metrics.total_sessions >= 300:
            factors.append(f"High session count: {metrics.total_sessions}")
        if metrics.uptime_hours >= 2000:
            factors.append(f"High uptime hours: {metrics.uptime_hours:.0f}")
        if metrics.last_maintenance is None:
            factors.append("Missing last maintenance date")
        else:
            now = datetime.now(timezone.utc)
            lm = metrics.last_maintenance if metrics.last_maintenance.tzinfo else metrics.last_maintenance.replace(tzinfo=timezone.utc)
            days = (now - lm).days
            factors.append(f"Days since maintenance: {days}d")
        if metrics.connector_status in {"FAULTY", "OFFLINE", "UNAVAILABLE"}:
            factors.append(f"Connector status: {metrics.connector_status}")
        return factors[:6]

    def _predict_window(self, prob: float, confidence: float) -> PredictedFailureWindow:
        now = datetime.now(timezone.utc)

        # expected days until failure: higher prob -> sooner
        expected_days = 1.0 + (1.0 - prob) * 30.0  # 1..31 days
        # uncertainty band: lower confidence -> wider window
        band_days = 1.0 + (1.0 - confidence) * 7.0  # 1..8 days
        start = now + timedelta(days=max(expected_days - band_days, 0.0))
        end = now + timedelta(days=expected_days + band_days)
        return PredictedFailureWindow(start=start, end=end)

    def predict(self, metrics: ChargerMetrics, tenant_id: Optional[str] = None) -> FailurePredictionResponse:
        features = extract_features(metrics)
        vec = np.array([features_to_vector(features)], dtype=float)

        proba = float(self.model.predict_proba(vec)[0][1])
        confidence = self._confidence(proba)

        predicted_window = self._predict_window(proba, confidence)
        action_window = self._recommend_action_window(proba, metrics)
        actions = self._recommend_actions(proba, metrics)
        factors = self._top_factors(metrics)

        return FailurePredictionResponse(
            charger_id=metrics.charger_id,
            tenant_id=tenant_id,
            failure_probability=proba,
            predicted_failure_window=predicted_window,
            confidence_score=confidence,
            recommended_action_window=action_window,  # type: ignore[arg-type]
            recommended_actions=actions,
            top_contributing_factors=factors,
        )

from __future__ import annotations

import json
import logging
from typing import Any, Dict, Optional

from kafka import KafkaProducer

from ..core.config import settings

logger = logging.getLogger(__name__)


class Producer:
    def __init__(self):
        self._producer: Optional[KafkaProducer] = None

    def _get(self) -> KafkaProducer:
        if self._producer is None:
            self._producer = KafkaProducer(
                bootstrap_servers=settings.KAFKA_BOOTSTRAP_SERVERS,
                value_serializer=lambda v: json.dumps(v).encode("utf-8"),
                linger_ms=50,
            )
        return self._producer

    def send(self, topic: str, payload: Dict[str, Any]) -> None:
        try:
            p = self._get()
            p.send(topic, payload)
            p.flush(2)
        except Exception:
            logger.exception("Kafka produce failed")

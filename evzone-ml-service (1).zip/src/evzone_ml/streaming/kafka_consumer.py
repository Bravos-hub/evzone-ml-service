from __future__ import annotations

import json
import logging
import threading
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from kafka import KafkaConsumer

from ..core.config import settings
from ..api.schemas import AnomalyDetectionRequest, ChargerMetrics, FailurePredictionRequest
from ..ml.anomaly_model import AnomalyDetector
from ..ml.failure_model import FailurePredictor
from .kafka_producer import Producer

logger = logging.getLogger(__name__)

_thread: Optional[threading.Thread] = None


def _parse_message(value: bytes) -> Dict[str, Any]:
    try:
        return json.loads(value.decode("utf-8"))
    except Exception:
        logger.exception("Invalid JSON message")
        return {}


def _to_anomaly_request(msg: Dict[str, Any]) -> Optional[AnomalyDetectionRequest]:
    try:
        ts = msg.get("timestamp")
        if isinstance(ts, str):
            timestamp = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        else:
            timestamp = datetime.now(timezone.utc)

        return AnomalyDetectionRequest(
            charger_id=str(msg.get("charger_id")),
            timestamp=timestamp,
            connector_status=str(msg.get("connector_status", "AVAILABLE")).upper(),
            energy_delivered=float(msg.get("energy_delivered", 0.0)),
            power=float(msg.get("power", 0.0)),
            temperature=float(msg.get("temperature", 0.0)),
            error_codes=list(msg.get("error_codes", []) or []),
            metadata=dict(msg.get("metadata", {}) or {}),
        )
    except Exception:
        logger.exception("Failed to parse anomaly request")
        return None


def _to_charger_metrics(msg: Dict[str, Any]) -> Optional[ChargerMetrics]:
    try:
        lm = msg.get("last_maintenance")
        last_maintenance = None
        if isinstance(lm, str) and lm:
            last_maintenance = datetime.fromisoformat(lm.replace("Z", "+00:00"))

        return ChargerMetrics(
            charger_id=str(msg.get("charger_id")),
            connector_status=str(msg.get("connector_status", "AVAILABLE")).upper(),
            energy_delivered=float(msg.get("energy_delivered", 0.0)),
            power=float(msg.get("power", 0.0)),
            temperature=float(msg.get("temperature", 0.0)),
            error_codes=list(msg.get("error_codes", []) or []),
            uptime_hours=float(msg.get("uptime_hours", 0.0)),
            total_sessions=int(msg.get("total_sessions", 0)),
            last_maintenance=last_maintenance,
            metadata=dict(msg.get("metadata", {}) or {}),
        )
    except Exception:
        logger.exception("Failed to parse charger metrics")
        return None


def _consumer_loop():
    logger.info("Kafka consumer loop starting: %s", settings.KAFKA_BOOTSTRAP_SERVERS)

    consumer = KafkaConsumer(
        settings.KAFKA_METRICS_TOPIC,
        bootstrap_servers=settings.KAFKA_BOOTSTRAP_SERVERS,
        group_id=settings.KAFKA_GROUP_ID,
        auto_offset_reset="latest",
        enable_auto_commit=True,
        value_deserializer=lambda v: v,  # keep bytes
    )

    anomaly = AnomalyDetector()
    failure = FailurePredictor()
    producer = Producer()

    for msg in consumer:
        data = _parse_message(msg.value)
        if not data:
            continue

        tenant_id = data.get("tenant_id") or data.get("operator_id") or None

        # 1) anomaly detection (real-time)
        areq = _to_anomaly_request(data)
        if areq:
            ares = anomaly.detect(areq, tenant_id=tenant_id)
            if ares.is_anomaly:
                out = ares.model_dump()
                out["source_topic"] = settings.KAFKA_METRICS_TOPIC
                producer.send(settings.KAFKA_ANOMALIES_TOPIC, out)
                logger.info("Anomaly published: %s", out)

        # 2) optional: failure scoring on each message (can be expensive at high volume)
        cm = _to_charger_metrics(data)
        if cm:
            fres = failure.predict(cm, tenant_id=tenant_id)
            if fres.failure_probability >= 0.85:
                out = fres.model_dump()
                out["source_topic"] = settings.KAFKA_METRICS_TOPIC
                producer.send("charger.failure_alerts", out)
                logger.info("Failure alert published: %s", out)


def start_consumer_thread() -> None:
    global _thread
    if _thread and _thread.is_alive():
        return
    _thread = threading.Thread(target=_consumer_loop, daemon=True)
    _thread.start()

from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    APP_NAME: str = "evzone-ml-service"
    LOG_LEVEL: str = "INFO"

    # Where *.joblib model files live
    MODEL_DIR: str = "models"

    # Kafka settings
    ENABLE_KAFKA_CONSUMER: bool = False
    KAFKA_BOOTSTRAP_SERVERS: str = "localhost:9092"
    KAFKA_METRICS_TOPIC: str = "charger.metrics"
    KAFKA_ANOMALIES_TOPIC: str = "charger.anomalies"
    KAFKA_GROUP_ID: str = "evzone-ml-consumer"

    # Multi-tenant header (optional)
    TENANT_HEADER: str = "X-Tenant-ID"


settings = Settings()
